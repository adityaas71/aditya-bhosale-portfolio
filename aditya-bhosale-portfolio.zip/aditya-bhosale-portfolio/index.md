
---
layout: home
title: "Welcome"
---

Hi, I'm **Aditya Ashok Bhosale** — a Ph.D. candidate in Biomedical Engineering at the University at Buffalo. My work focuses on RF coil design, electromagnetic simulation, and system-level innovation for very-low-field and ultrahigh-field MRI.
